
// Firebase loaded from firebase-config.js (user version)
const auth = firebase.auth();

const emailEl = document.getElementById('email');
const passEl = document.getElementById('password');
const authSection = document.getElementById('auth-section');
const userSection = document.getElementById('user-section');
const welcome = document.getElementById('welcome');

document.getElementById('btn-signup').onclick = () => {
  auth.createUserWithEmailAndPassword(emailEl.value, passEl.value)
      .then(() => alert("Usuário criado!"))
      .catch(e => alert(e.message));
};

document.getElementById('btn-signin').onclick = () => {
  auth.signInWithEmailAndPassword(emailEl.value, passEl.value)
      .catch(e => alert(e.message));
};

document.getElementById('btn-google').onclick = () => {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider).catch(e => alert(e.message));
};

document.getElementById('btn-signout').onclick = () => auth.signOut();

auth.onAuthStateChanged(user => {
  if (user) {
    authSection.classList.add("hidden");
    userSection.classList.remove("hidden");
    welcome.textContent = "Bem-vindo, " + (user.displayName || user.email);
  } else {
    authSection.classList.remove("hidden");
    userSection.classList.add("hidden");
  }
});
